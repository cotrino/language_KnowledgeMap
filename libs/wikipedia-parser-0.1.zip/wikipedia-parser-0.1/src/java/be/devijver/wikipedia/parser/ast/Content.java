package be.devijver.wikipedia.parser.ast;

/**
 * Created by IntelliJ IDEA.
 * User: steven
 * Date: 4-nov-2006
 * Time: 22:49:01
 * To change this template use File | Settings | File Templates.
 */
public interface Content {
}
