package be.devijver.wikipedia.parser.wikitext;

/**
 * Created by IntelliJ IDEA.
 * User: steven
 * Date: 4-nov-2006
 * Time: 18:32:30
 * To change this template use File | Settings | File Templates.
 */
public class MarkupParseException extends RuntimeException {

    public MarkupParseException(String s) {
        super(s);
    }
}
