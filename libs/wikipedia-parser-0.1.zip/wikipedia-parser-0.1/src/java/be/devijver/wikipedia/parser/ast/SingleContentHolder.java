package be.devijver.wikipedia.parser.ast;

/**
 * Created by IntelliJ IDEA.
 * User: steven
 * Date: 5-nov-2006
 * Time: 11:12:51
 * To change this template use File | Settings | File Templates.
 */
public interface SingleContentHolder extends Content {
    Content getContent();
}
