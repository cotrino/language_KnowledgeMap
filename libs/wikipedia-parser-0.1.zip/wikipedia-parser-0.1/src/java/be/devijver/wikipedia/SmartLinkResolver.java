package be.devijver.wikipedia;

public interface SmartLinkResolver {

	String resolve(String smartLink);
}
