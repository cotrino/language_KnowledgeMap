package be.devijver.wikipedia.parser.ast;

/**
 * Created by IntelliJ IDEA.
 * User: steven
 * Date: 4-nov-2006
 * Time: 18:10:58
 * To change this template use File | Settings | File Templates.
 */
public class Paragraph extends AbstractContentHolder {
    public Paragraph(Content[] content) {
        super(content);
    }
}
