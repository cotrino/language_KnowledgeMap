package be.devijver.wikipedia.html;

public interface HtmlEncoder {

	String encode(String s);
}
